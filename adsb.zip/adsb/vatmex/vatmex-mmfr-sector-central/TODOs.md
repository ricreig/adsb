# TODOS

* Separar aproximación Bajio
* Actualiza corredores visuales TMA Mexico 2405
